<template>
  <div id="app">
    <link rel="stylesheet" type="text/css" href="http://cdn.bootcss.com/material-design-icons/3.0.1/iconfont/material-icons.css"/>    
    <router-view />
  </div>
</template>

<script>
export default {
  name: "App",
  computed: {}
};
</script>

<style lang="scss">
  @import './assets/css/main.css'
</style>
