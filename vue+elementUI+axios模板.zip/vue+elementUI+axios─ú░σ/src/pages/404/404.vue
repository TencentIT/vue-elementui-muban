<template>
  <div class="container-box">
    404 page
  </div>
</template>

<script>
export default {
   data() {
      return {

      }
   },
   created() {

   },
   methods:{

   }
}
</script>

<style lang='scss' scoped>

</style>