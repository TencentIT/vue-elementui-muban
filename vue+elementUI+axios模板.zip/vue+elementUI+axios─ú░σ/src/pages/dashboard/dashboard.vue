<template>
  <div class="container-box">dashboard page</div>
</template>

<script>
export default {
  data() {
    return {};
  },
  created() {},
  methods: {}
};
</script>

<style lang='scss' scoped>
</style>