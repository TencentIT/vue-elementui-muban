<template>
  <div class="container-box">report page</div>
</template>

<script>
export default {
  data() {
    return {};
  },
  created() {},
  methods: {}
};
</script>

<style lang='scss' scoped>
</style>