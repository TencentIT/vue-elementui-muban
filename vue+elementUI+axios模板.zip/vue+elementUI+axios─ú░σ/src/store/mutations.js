import types from './types'

export default {
  setBreadcrumb(state, breadcrumb) {
    state['breadcrumb'] = breadcrumb
  }
}