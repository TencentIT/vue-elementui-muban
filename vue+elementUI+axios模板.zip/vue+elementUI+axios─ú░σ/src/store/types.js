import helpers from '@/utils/helpers/base'

export default helpers.keyMirror({
	BREADCRUMB: null
})